export declare function getValue<T>(obj: T, path: keyof T): any;
export declare function setValue(obj: any, prop: string, val: any): any;
