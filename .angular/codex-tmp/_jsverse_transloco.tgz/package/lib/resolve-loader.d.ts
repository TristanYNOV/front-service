import { TranslocoLoader, TranslocoLoaderData } from './transloco.loader';
import { InlineLoader } from './transloco.types';
interface Options {
    inlineLoader?: InlineLoader;
    path: string;
    mainLoader: TranslocoLoader;
    data?: TranslocoLoaderData;
}
export declare function resolveLoader(options: Options): import("rxjs").Observable<import("./transloco.types").Translation> | Promise<any>;
export {};
