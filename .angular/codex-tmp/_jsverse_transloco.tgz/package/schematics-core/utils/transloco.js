"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getGlobalConfig = getGlobalConfig;
exports.createGlobalConfig = createGlobalConfig;
exports.updateGlobalConfig = updateGlobalConfig;
const transloco_utils_1 = require("@jsverse/transloco-utils");
const schematic_1 = require("./schematic");
let config;
function getGlobalConfig() {
    if (config)
        return config;
    config = (0, transloco_utils_1.getGlobalConfig)();
    return config;
}
function createGlobalConfig(host, langs, rootTranslationsPath = 'assets/i18n/') {
    if (!host.get(schematic_1.NAMES.CONFIG_FILE)) {
        host.create(schematic_1.NAMES.CONFIG_FILE, (0, schematic_1.generateConfigFile)({
            rootTranslationsPath: rootTranslationsPath,
            langs,
            keysManager: {},
        }));
    }
}
function updateGlobalConfig(host, config) {
    const originalConfig = getGlobalConfig();
    if (!originalConfig || Object.keys(originalConfig).length === 0) {
        return createGlobalConfig(host, config.langs || [], config.rootTranslationsPath);
    }
    host.overwrite(schematic_1.NAMES.CONFIG_FILE, (0, schematic_1.generateConfigFile)(Object.assign(Object.assign({}, config), originalConfig)));
}
//# sourceMappingURL=transloco.js.map