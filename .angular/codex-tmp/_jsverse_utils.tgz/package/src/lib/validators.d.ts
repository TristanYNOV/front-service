export declare function isFunction(val: unknown): val is CallableFunction;
export declare function isString(val: unknown): val is string;
export declare function isNumber(val: unknown): val is number;
export declare function isObject(item: unknown): item is Record<string, unknown>;
export declare function isNil(value: unknown): value is null | undefined;
export declare function isDefined(value: unknown): boolean;
