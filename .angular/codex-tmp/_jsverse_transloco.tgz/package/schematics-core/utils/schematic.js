"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NAMES = void 0;
exports.generateConfigFile = generateConfigFile;
const node_util_1 = require("node:util");
exports.NAMES = {
    LIB_NAME: '@jsverse/transloco',
    CONFIG_FILE: 'transloco.config.ts',
};
function generateConfigFile(config) {
    return `import {TranslocoGlobalConfig} from '@jsverse/transloco-utils';
    
const config: TranslocoGlobalConfig = ${(0, node_util_1.inspect)(config)};
    
export default config;`;
}
//# sourceMappingURL=schematic.js.map