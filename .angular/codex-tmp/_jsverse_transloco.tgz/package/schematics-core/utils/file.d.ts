import { PathFragment } from '@angular-devkit/core';
import { DirEntry, Tree } from '@angular-devkit/schematics';
export declare function getJsonFileContent(fileName: PathFragment, dir: DirEntry): any;
export declare function writeToJson(host: Tree, dirPath: string, fileName: PathFragment, content: unknown): void;
export declare function hasSubdirs(dir: DirEntry): boolean;
export declare function hasFiles(dir: DirEntry): boolean;
