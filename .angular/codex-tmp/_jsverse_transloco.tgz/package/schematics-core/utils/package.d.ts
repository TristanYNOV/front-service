import { Tree } from '@angular-devkit/schematics';
export declare function addScriptToPackageJson(host: Tree, scriptName: string, script: string): Tree;
