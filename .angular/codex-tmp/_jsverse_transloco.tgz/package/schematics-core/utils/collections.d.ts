export declare function stringifyList<T>(list: T[], separator?: string): string;
export declare function coerceArray<T>(value: T | T[]): T[];
export declare function coerceArray<T>(value: T | readonly T[]): readonly T[];
