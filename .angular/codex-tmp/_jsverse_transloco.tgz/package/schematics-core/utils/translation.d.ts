import { Tree } from '@angular-devkit/schematics';
export declare function createTranslateFiles(langs: string[], path: string): import("@angular-devkit/schematics").Source;
export declare function checkIfTranslationFilesExist(path: string, langs: string[], extension: string, skipThrow?: boolean): boolean;
export declare function createTranslateFilesFromOptions(_: Tree, options: {
    langs: string[];
    translationFilePath: string;
}): import("@angular-devkit/schematics").Source;
export declare function getTranslationKey(prefix: string | undefined, key: string): string;
export declare function getTranslationsRoot(host: Tree, options: {
    project?: string;
    translationPath?: string;
}): string;
export declare function getTranslationFiles(host: Tree, root: string): {
    lang: string;
    translation: Record<string, unknown>;
}[];
export declare function getTranslationEntryPaths(host: Tree, rootDirPath: string): {
    scope: string;
    path: string;
}[];
