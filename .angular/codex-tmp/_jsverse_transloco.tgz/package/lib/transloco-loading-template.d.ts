import { InjectionToken } from '@angular/core';
import { Content } from './template-handler';
export declare const TRANSLOCO_LOADING_TEMPLATE: InjectionToken<Content>;
