import { InlineLoader, LoadedEvent, ProviderScope, TranslocoScope } from '../transloco.types';
export declare function getScopeFromLang(lang: string): string;
export declare function getLangFromScope(lang: string): string;
export declare function isScopeObject(item: any): item is ProviderScope;
export declare function hasInlineLoader(item: any): item is ProviderScope;
export declare function resolveInlineLoader(providerScope: TranslocoScope | null, scope?: string): InlineLoader | undefined;
export declare function getEventPayload(lang: string): LoadedEvent['payload'];
