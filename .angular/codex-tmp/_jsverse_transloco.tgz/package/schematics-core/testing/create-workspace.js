"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.defaultAppOptions = exports.defaultWorkspaceOptions = void 0;
exports.createWorkspace = createWorkspace;
const schema_1 = require("@schematics/angular/application/schema");
exports.defaultWorkspaceOptions = {
    name: 'workspace',
    newProjectRoot: 'projects',
    version: '16.0.4',
    minimal: true,
};
exports.defaultAppOptions = {
    name: 'bar',
    inlineStyle: false,
    inlineTemplate: false,
    viewEncapsulation: schema_1.ViewEncapsulation.Emulated,
    routing: false,
    style: schema_1.Style.Css,
    skipTests: false,
};
const defaultLibOptions = {
    name: 'baz',
};
function createWorkspace(schematicRunner, options = {}) {
    const appOptions = Object.assign(Object.assign({}, exports.defaultAppOptions), options.appOptions);
    const workspaceOptions = Object.assign(Object.assign({}, exports.defaultWorkspaceOptions), options.workspaceOptions);
    const libOptions = Object.assign(Object.assign({}, defaultLibOptions), options.libOptions);
    const angularSchematic = '@schematics/angular';
    return schematicRunner
        .runExternalSchematic(angularSchematic, 'workspace', workspaceOptions)
        .then((tree) => schematicRunner.runExternalSchematic(angularSchematic, 'application', appOptions, tree))
        .then((tree) => schematicRunner.runExternalSchematic(angularSchematic, 'library', libOptions, tree));
}
//# sourceMappingURL=create-workspace.js.map