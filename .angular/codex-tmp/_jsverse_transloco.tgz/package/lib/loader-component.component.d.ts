import * as i0 from "@angular/core";
export declare class TranslocoLoaderComponent {
    html: string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslocoLoaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TranslocoLoaderComponent, "ng-component", never, { "html": { "alias": "html"; "required": false; }; }, {}, never, never, true, never>;
}
