import { InjectionToken } from '@angular/core';
import { TranslocoScope } from './transloco.types';
export declare const TRANSLOCO_SCOPE: InjectionToken<TranslocoScope>;
