import { TemplateRef, Type, ViewContainerRef } from '@angular/core';
export type Content = string | TemplateRef<unknown> | Type<unknown>;
export declare class TemplateHandler {
    private view;
    private vcr;
    constructor(view: Content, vcr: ViewContainerRef);
    attachView(): void;
    detachView(): void;
}
