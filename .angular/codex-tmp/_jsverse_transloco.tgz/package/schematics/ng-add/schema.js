"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Loaders = void 0;
var Loaders;
(function (Loaders) {
    Loaders["Http"] = "Http";
    Loaders["Webpack"] = "Webpack";
})(Loaders || (exports.Loaders = Loaders = {}));
//# sourceMappingURL=schema.js.map