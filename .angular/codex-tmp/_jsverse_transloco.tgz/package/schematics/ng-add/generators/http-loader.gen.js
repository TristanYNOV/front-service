"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createLoaderFile = createLoaderFile;
const schematics_1 = require("@angular-devkit/schematics");
function createLoaderFile({ ssr, loaderPath, urlPath, }) {
    return (0, schematics_1.apply)((0, schematics_1.url)(`./files/transloco-loader`), [
        (0, schematics_1.template)({
            // Replace the __ts__ with ts
            ts: 'ts',
            loaderPrefix: ssr ? '${environment.baseUrl}' : '',
            urlPath: urlPath,
        }),
        (0, schematics_1.move)('/', loaderPath),
    ]);
}
//# sourceMappingURL=http-loader.gen.js.map