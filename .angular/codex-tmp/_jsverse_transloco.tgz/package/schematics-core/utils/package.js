"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addScriptToPackageJson = addScriptToPackageJson;
function addScriptToPackageJson(host, scriptName, script) {
    var _a;
    const packageFile = host.read('package.json');
    if (packageFile !== null) {
        const sourceText = packageFile.toString('utf-8');
        const json = JSON.parse(sourceText);
        (_a = json['scripts']) !== null && _a !== void 0 ? _a : (json['scripts'] = {});
        json['scripts'][scriptName] = script;
        host.overwrite('package.json', JSON.stringify(json, null, 2));
    }
    return host;
}
//# sourceMappingURL=package.js.map