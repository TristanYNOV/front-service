import { Translation } from '../transloco.types';
export declare function flatten(obj: Translation): Translation;
export declare function unflatten(obj: Translation): Translation;
