import { Rule } from '@angular-devkit/schematics';
import { SchemaOptions } from './schema';
export declare function ngAdd(options: SchemaOptions): Rule;
