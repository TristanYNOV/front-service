import { OperatorFunction } from 'rxjs';
import { TranslocoService } from '../transloco.service';
export declare function shouldListenToLangChanges(service: TranslocoService, lang?: string): boolean;
export declare function listenOrNotOperator<T>(listenToLangChange?: boolean): OperatorFunction<T, T>;
