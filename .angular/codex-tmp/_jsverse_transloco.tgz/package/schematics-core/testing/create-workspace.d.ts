import { SchematicTestRunner } from '@angular-devkit/schematics/testing';
import type { Schema as WorkspaceSchema } from '@schematics/angular/workspace/schema';
import { Schema as ApplicationSchema } from '@schematics/angular/application/schema';
import type { Schema as LibrarySchema } from '@schematics/angular/library/schema';
export declare const defaultWorkspaceOptions: WorkspaceSchema;
export declare const defaultAppOptions: ApplicationSchema;
export declare function createWorkspace(schematicRunner: SchematicTestRunner, options?: {
    workspaceOptions?: Partial<WorkspaceSchema>;
    appOptions?: Partial<ApplicationSchema>;
    libOptions?: Partial<LibrarySchema>;
}): Promise<import("@angular-devkit/schematics/testing").UnitTestTree>;
