"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.stringifyList = stringifyList;
exports.coerceArray = coerceArray;
function stringifyList(list, separator = ', ') {
    return list.map((item) => `'${item}'`).join(separator);
}
function coerceArray(value) {
    return Array.isArray(value) ? value : [value];
}
//# sourceMappingURL=collections.js.map