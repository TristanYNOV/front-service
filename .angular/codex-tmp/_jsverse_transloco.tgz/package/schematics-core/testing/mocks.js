"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.translationMocks = void 0;
exports.translationMocks = {
    en: { hello: 'hello' },
    es: { hello: 'hola' },
    scopeEn: { hello: 'hello scope' },
    scopeEs: { hello: 'hola scope' },
};
//# sourceMappingURL=mocks.js.map