"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getJsonFileContent = getJsonFileContent;
exports.writeToJson = writeToJson;
exports.hasSubdirs = hasSubdirs;
exports.hasFiles = hasFiles;
const nodePath = require("node:path");
function getJsonFileContent(fileName, dir) {
    const content = dir.file(fileName).content.toString('utf-8');
    return JSON.parse(content);
}
function writeToJson(host, dirPath, fileName, content) {
    return host.overwrite(nodePath.join(dirPath, fileName), JSON.stringify(content, null, 2));
}
function hasSubdirs(dir) {
    return dir.subdirs && dir.subdirs.length > 0;
}
function hasFiles(dir) {
    return dir.subfiles && dir.subfiles.length > 0;
}
//# sourceMappingURL=file.js.map