import { OrArray } from '@jsverse/utils';
import { TranslocoScope } from './transloco.types';
import { TranslocoService } from './transloco.service';
type ScopeResolverParams = {
    inline: string | undefined;
    provider: OrArray<TranslocoScope> | null;
};
export declare class ScopeResolver {
    private service;
    constructor(service: TranslocoService);
    resolve(params: ScopeResolverParams): string | undefined;
}
export {};
