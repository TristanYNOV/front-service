export declare const translationMocks: {
    en: {
        hello: string;
    };
    es: {
        hello: string;
    };
    scopeEn: {
        hello: string;
    };
    scopeEs: {
        hello: string;
    };
};
