"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createTranslocoModule = createTranslocoModule;
const path = require("node:path");
const schematics_1 = require("@angular-devkit/schematics");
const schematics_core_1 = require("../../../schematics-core");
function createTranslocoModule({ isLib, ssr, langs, modulePath, sourceRoot, host, }) {
    const envPath = path
        .relative(modulePath, `${sourceRoot}/environments/environment`)
        .split(path.sep)
        .join('/');
    const envFileExists = host.exists(`${sourceRoot}/environments/environment.ts`);
    let prodMode = envFileExists ? 'environment.production' : '!isDevMode()';
    if (isLib) {
        prodMode = 'false';
    }
    return (0, schematics_1.apply)((0, schematics_1.url)(`./files/transloco-module`), [
        (0, schematics_1.template)({
            // Replace the __ts__ with ts
            ts: 'ts',
            stringifyList: schematics_core_1.stringifyList,
            langs,
            importEnv: ssr || envFileExists,
            envPath,
            prodMode,
        }),
        (0, schematics_1.move)('/', modulePath),
    ]);
}
//# sourceMappingURL=root-module.gen.js.map