export declare function size(collection: unknown): number;
export declare function isEmpty(collection: any): boolean;
