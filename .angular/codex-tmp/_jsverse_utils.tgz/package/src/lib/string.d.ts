export declare function toCamelCase(str: string): string;
export declare function toNumber(value: number | string): number | null;
