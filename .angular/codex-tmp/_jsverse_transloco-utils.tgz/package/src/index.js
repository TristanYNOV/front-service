"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getGlobalConfig = void 0;
var transloco_utils_1 = require("./lib/transloco-utils");
Object.defineProperty(exports, "getGlobalConfig", { enumerable: true, get: function () { return transloco_utils_1.getGlobalConfig; } });
