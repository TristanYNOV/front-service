import { Tree } from '@angular-devkit/schematics';
import { TranslocoGlobalConfig } from '@jsverse/transloco-utils';
export declare function getGlobalConfig(): TranslocoGlobalConfig;
export declare function createGlobalConfig(host: Tree, langs: string[], rootTranslationsPath?: string): void;
export declare function updateGlobalConfig(host: Tree, config: TranslocoGlobalConfig): void;
