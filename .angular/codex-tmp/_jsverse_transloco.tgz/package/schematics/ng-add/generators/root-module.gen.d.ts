import { Source, Tree } from '@angular-devkit/schematics';
export declare function createTranslocoModule({ isLib, ssr, langs, modulePath, sourceRoot, host, }: {
    isLib: boolean;
    ssr: boolean;
    langs: string[];
    modulePath: string;
    sourceRoot: string;
    host: Tree;
}): Source;
