import { TranslocoGlobalConfig } from '@jsverse/transloco-utils';
export declare const NAMES: {
    LIB_NAME: string;
    CONFIG_FILE: string;
};
export declare function generateConfigFile(config: TranslocoGlobalConfig): string;
