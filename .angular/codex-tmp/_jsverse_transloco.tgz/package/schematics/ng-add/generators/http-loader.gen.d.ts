export interface CreateLoaderFileParams {
    ssr: boolean;
    loaderPath: string;
    urlPath: string;
}
export declare function createLoaderFile({ ssr, loaderPath, urlPath, }: CreateLoaderFileParams): import("@angular-devkit/schematics").Source;
