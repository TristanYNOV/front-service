"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getWorkspace = getWorkspace;
exports.setWorkspace = setWorkspace;
exports.getProject = getProject;
exports.setEnvironments = setEnvironments;
const schematics_1 = require("@angular-devkit/schematics");
function getWorkspacePath(host) {
    const possibleFiles = ['/angular.json', '/.angular.json'];
    const [path] = possibleFiles.filter((path) => host.exists(path));
    return path;
}
function getWorkspace(host) {
    const path = getWorkspacePath(host);
    const configBuffer = host.read(path);
    if (configBuffer === null) {
        throw new schematics_1.SchematicsException(`Could not find (${path})`);
    }
    const config = configBuffer.toString();
    return JSON.parse(config);
}
function setWorkspace(host, workspace) {
    const path = getWorkspacePath(host);
    host.overwrite(path, JSON.stringify(workspace, null, 2));
}
function getProject(host, project) {
    const workspace = getWorkspace(host);
    if (workspace) {
        return workspace.projects[project];
    }
    throw new schematics_1.SchematicsException('could not find a workspace project');
}
function setEnvironments(host, sourceRoot, transformer) {
    const path = sourceRoot + '/environments';
    const environments = host.getDir(path);
    return environments.subfiles.forEach((file) => {
        const filePath = `${path}/${file}`;
        const configBuffer = host.read(filePath);
        const source = configBuffer.toString('utf-8');
        host.overwrite(filePath, transformer(source));
    });
}
//# sourceMappingURL=workspace.js.map