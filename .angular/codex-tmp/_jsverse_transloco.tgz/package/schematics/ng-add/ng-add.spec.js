"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const nodePath = require("node:path");
const testing_1 = require("@angular-devkit/schematics/testing");
const testing_2 = require("../../schematics-core/testing");
const collectionPath = nodePath.join(__dirname, '../collection.json');
describe('ng add', () => {
    const schematicRunner = new testing_1.SchematicTestRunner('schematics', collectionPath);
    describe('Ng module', () => {
        it(`GIVEN an NgModule-based Angular project
        WHEN ng-add schematic runs for project 'bar'
        THEN transloco config, loader, and root module are created`, () => __awaiter(void 0, void 0, void 0, function* () {
            const options = { project: 'bar' };
            const tree = yield schematicRunner.runSchematic('ng-add', options, yield (0, testing_2.createWorkspace)(schematicRunner, {
                appOptions: { standalone: false },
            }));
            expect(tree).toBeDefined();
            expect(tree.files).toContain('/transloco.config.ts');
            expect(tree.files).toContain('/projects/bar/src/app/transloco-loader.ts');
            expect(tree.files).toContain('/projects/bar/src/app/transloco-root.module.ts');
            expect(readFile(tree, 'app/transloco-root.module.ts')).toContain("from './transloco-loader'");
        }));
    });
    describe('Standalone', () => {
        it(`GIVEN a standalone Angular project
        WHEN ng-add schematic runs for project 'bar'
        THEN transloco config and loader are created and provideTransloco is added to app.config.ts`, () => __awaiter(void 0, void 0, void 0, function* () {
            const options = { project: 'bar' };
            const tree = yield schematicRunner.runSchematic('ng-add', options, yield (0, testing_2.createWorkspace)(schematicRunner));
            expect(tree).toBeDefined();
            expect(tree.files).toContain('/transloco.config.ts');
            expect(tree.files).toContain('/projects/bar/src/app/transloco-loader.ts');
            expect(readFile(tree, 'app/app.config.ts')).toContain('provideTransloco(');
        }));
    });
    describe('Folder Detection', () => {
        it(`GIVEN an Angular 18+ project with public folder
        WHEN ng-add schematic runs
        THEN translation files are created in public/i18n and loader uses correct path`, () => __awaiter(void 0, void 0, void 0, function* () {
            const options = { project: 'bar' };
            const initialTree = yield (0, testing_2.createWorkspace)(schematicRunner);
            // Create public folder to simulate Angular 18+
            initialTree.create('/public/favicon.ico', '');
            const tree = yield schematicRunner.runSchematic('ng-add', options, initialTree);
            expect(tree.files).toContain('/public/i18n/en.json');
            expect(tree.files).toContain('/public/i18n/es.json');
            // Check that loader uses correct URL path
            const loaderContent = readFile(tree, 'app/transloco-loader.ts');
            expect(loaderContent).toContain('/i18n/${lang}.json');
            expect(loaderContent).not.toContain('/assets/i18n/');
        }));
        it(`GIVEN a project with assets folder structure
        WHEN ng-add schematic runs
        THEN translation files are created in src/assets/i18n and loader uses correct path`, () => __awaiter(void 0, void 0, void 0, function* () {
            const options = { project: 'bar' };
            const initialTree = yield (0, testing_2.createWorkspace)(schematicRunner);
            // Create assets folder to simulate traditional Angular structure
            initialTree.create('/projects/bar/src/assets/icons/icon.png', '');
            const tree = yield schematicRunner.runSchematic('ng-add', options, initialTree);
            expect(tree.files).toContain('/projects/bar/src/assets/i18n/en.json');
            expect(tree.files).toContain('/projects/bar/src/assets/i18n/es.json');
            // Check that loader uses correct URL path
            const loaderContent = readFile(tree, 'app/transloco-loader.ts');
            expect(loaderContent).toContain('/assets/i18n/${lang}.json');
        }));
        it(`GIVEN ng-add schematic with custom path option
        WHEN schematic runs
        THEN translation files are created in custom path and loader uses correct path`, () => __awaiter(void 0, void 0, void 0, function* () {
            const options = {
                project: 'bar',
                path: 'custom/translations/',
            };
            const tree = yield schematicRunner.runSchematic('ng-add', options, yield (0, testing_2.createWorkspace)(schematicRunner));
            expect(tree.files).toContain('/projects/bar/src/custom/translations/en.json');
            expect(tree.files).toContain('/projects/bar/src/custom/translations/es.json');
            // Check that loader uses correct URL path
            const loaderContent = readFile(tree, 'app/transloco-loader.ts');
            expect(loaderContent).toContain('/custom/translations/${lang}.json');
        }));
        it(`GIVEN an Angular 18+ project without explicit folder indicators
        WHEN ng-add schematic runs and checks package.json
        THEN public/i18n is used based on Angular version detection`, () => __awaiter(void 0, void 0, void 0, function* () {
            const options = { project: 'bar' };
            const initialTree = yield (0, testing_2.createWorkspace)(schematicRunner);
            // Simulate Angular 18+ by updating package.json
            const packageJson = JSON.parse(initialTree.read('/package.json').toString());
            packageJson.dependencies['@angular/core'] = '^18.0.0';
            initialTree.overwrite('/package.json', JSON.stringify(packageJson, null, 2));
            const tree = yield schematicRunner.runSchematic('ng-add', options, initialTree);
            expect(tree.files).toContain('/public/i18n/en.json');
            expect(tree.files).toContain('/public/i18n/es.json');
            // Check that loader uses correct URL path for Angular 18+
            const loaderContent = readFile(tree, 'app/transloco-loader.ts');
            expect(loaderContent).toContain('/i18n/${lang}.json');
        }));
        it(`GIVEN an Angular 17 project detected via package.json
        WHEN ng-add schematic runs
        THEN assets/i18n is used for pre-Angular 18 versions`, () => __awaiter(void 0, void 0, void 0, function* () {
            const options = { project: 'bar' };
            const initialTree = yield (0, testing_2.createWorkspace)(schematicRunner);
            // Simulate Angular 17 by updating package.json
            const packageJson = JSON.parse(initialTree.read('/package.json').toString());
            packageJson.dependencies['@angular/core'] = '^17.0.0';
            initialTree.overwrite('/package.json', JSON.stringify(packageJson, null, 2));
            const tree = yield schematicRunner.runSchematic('ng-add', options, initialTree);
            expect(tree.files).toContain('/projects/bar/src/assets/i18n/en.json');
            expect(tree.files).toContain('/projects/bar/src/assets/i18n/es.json');
            // Check that loader uses correct URL path for Angular <18
            const loaderContent = readFile(tree, 'app/transloco-loader.ts');
            expect(loaderContent).toContain('/assets/i18n/${lang}.json');
        }));
    });
});
function readFile(host, path) {
    return host.get(`/projects/bar/src/${path}`).content.toString();
}
//# sourceMappingURL=ng-add.spec.js.map