"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createTranslateFiles = createTranslateFiles;
exports.checkIfTranslationFilesExist = checkIfTranslationFilesExist;
exports.createTranslateFilesFromOptions = createTranslateFilesFromOptions;
exports.getTranslationKey = getTranslationKey;
exports.getTranslationsRoot = getTranslationsRoot;
exports.getTranslationFiles = getTranslationFiles;
exports.getTranslationEntryPaths = getTranslationEntryPaths;
const nodePath = require("node:path");
const fs = require("node:fs");
const schematics_1 = require("@angular-devkit/schematics");
const workspace_1 = require("./workspace");
const file_1 = require("./file");
const transloco_1 = require("./transloco");
function jsonTranslationFileCreator(source, lang) {
    source.create(`${lang}.json`, `{}
`);
}
function createTranslateFiles(langs, path) {
    const treeSource = new schematics_1.EmptyTree();
    for (const lang of langs) {
        jsonTranslationFileCreator(treeSource, lang);
    }
    return (0, schematics_1.apply)((0, schematics_1.source)(treeSource), [(0, schematics_1.move)('/', path)]);
}
function checkIfTranslationFilesExist(path, langs, extension, skipThrow) {
    for (const lang of langs) {
        const filePath = nodePath.resolve(`${path}/${lang}${extension}`);
        if (fs.existsSync(filePath)) {
            if (skipThrow) {
                return true;
            }
            throw new schematics_1.SchematicsException(`Translation file ${filePath} is already exist, please use --skip-creation`);
        }
    }
    return false;
}
function createTranslateFilesFromOptions(_, options) {
    const extension = '.json';
    checkIfTranslationFilesExist(options.translationFilePath, options.langs, extension);
    return createTranslateFiles(options.langs, options.translationFilePath);
}
function getTranslationKey(prefix = '', key) {
    return prefix ? `${prefix}.${key}` : key;
}
function getTranslationsRoot(host, options) {
    const translocoConfig = (0, transloco_1.getGlobalConfig)();
    if (options.translationPath) {
        return options.translationPath;
    }
    else if (translocoConfig && translocoConfig.rootTranslationsPath) {
        return translocoConfig.rootTranslationsPath;
    }
    else {
        const project = (0, workspace_1.getProject)(host, options.project || '');
        const rootPath = (project && project.sourceRoot) || 'src';
        return nodePath.join(rootPath, 'assets', 'i18n');
    }
}
function getTranslationFiles(host, root) {
    const rootDir = host.getDir(root);
    return rootDir.subfiles.map((fileName) => ({
        lang: fileName.split('.')[0],
        translation: (0, file_1.getJsonFileContent)(fileName, rootDir),
    }));
}
function getTranslationEntryPaths(host, rootDirPath) {
    const translocoConfig = (0, transloco_1.getGlobalConfig)();
    if (translocoConfig.scopePathMap &&
        Object.keys(translocoConfig.scopePathMap).length) {
        return Object.entries(translocoConfig.scopePathMap).map(([scope, path]) => ({
            scope,
            path: path,
        }));
    }
    const rootDir = host.getDir(rootDirPath);
    return rootDir.subdirs.map((subDir) => ({
        scope: subDir,
        path: nodePath.join(rootDirPath, subDir),
    }));
}
//# sourceMappingURL=translation.js.map